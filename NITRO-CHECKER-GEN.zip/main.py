#join for discord for help! https://discord.gg/6tKcCzEdfw
import random, string, requests, webbrowser, time
f =open ("wroking nitro codes.txt","w", encoding='utf-8')
print("BEST GEN JOIN FOR MORE: https://discord.gg/6tKcCzEdfw")


while True:
    code = ('').join(random.choices(string.ascii_letters + string.digits, k=16))
    r = requests.get(f"https://discordapp.com/api/v6/entitlements/gift-codes/{code}?with_application=false&with_subscription_plan=true")
    if r.status_code == 200:
        print(f"Valid Nitro Code > discord.gift/{code}")
        f.write(f"discord.gift/{code}\n")
    else:
        print(f"Invalid Nitro Code > discord.gift/{code}")
  
  #SOME cAt#0963 made this!